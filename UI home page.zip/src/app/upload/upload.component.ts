import { Component, OnInit } from '@angular/core';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { UploadService } from './upload.service';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map'

import { Upload } from '../../models/upload.model';
import { CommonService } from '../service/common.service';

const URL = 'http://localhost:4200/api/upload';

@Component({
  selector: 'app-upload-root',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css'],
  providers: [UploadService]
})
export class UploadComponent implements OnInit {
  title = 'app';
  public images: any[];
  public image_path;
  filesToUpload: Array<File> = [];

  constructor(private http: HttpClient, private UploadService: UploadService, private commonService: CommonService) {

  }

  public uploader: FileUploader = new FileUploader({ url: URL, itemAlias: 'photo' });

  upload() {
    const formData: any = new FormData();
    const files: Array<File> = this.filesToUpload;
    console.log(files);

    for(let i =0; i < files.length; i++){
        formData.append("uploads[]", files[i], files[i]['name']);
    }
    console.log('form data variable :   '+ formData.toString());
    this.http.post('http://localhost:4200/api/upload', formData)
        .map(files => files)
        .subscribe(files => console.log('files', files))
        this.commonService.notifyImageAddition();
}

fileChangeEvent(fileInput: any) {
    this.filesToUpload = <Array<File>>fileInput.target.files;
    //this.product.photo = fileInput.target.files[0]['name'];
}

  ngOnInit() {
    this.getAllImages();

    //to update post after adding 
    this.commonService.postAddedImage_Observable.subscribe(res => {
      this.getAllImages();
    });

    // this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    // this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
    //   console.log('ImageUpload:uploaded:', item, status, response);
    //   this.commonService.notifyImageAddition();
    // };
  }

  //Get all images
  getAllImages() {
    this.UploadService.getAllImages().subscribe(result => {
      this.images = result['data'];
    });
  }
}