import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-index-home',
  templateUrl: './index-home.component.html',
  styleUrls: ['./index-home.component.scss']
})
export class IndexHomeComponent {

  constructor(private router: Router) {

    
  }

}