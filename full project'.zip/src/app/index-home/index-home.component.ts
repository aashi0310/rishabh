import { Component, ViewChild, Renderer } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-index-home',
  templateUrl: './index-home.component.html',
  styleUrls: ['./index-home.component.scss']
})
export class IndexHomeComponent {

  private toggle : boolean = false;
  constructor(private router: Router, private render:Renderer) {

    
  }

  //Toggle responsive menu
  openHiddenMenu(event:any){
     this.toggle = this.toggle === false ? true : false;  
  }

  //Toggle responsive menu
  hideHiddenMenu(event:any){
    var divToChange = document.getElementById('resp-nav nav-icon')[0];
    divToChange.classList.remove('active'); 
    this.toggle = false;  
  }

}